# QBrick
QuantumGenesis takım projesidir. 2D kuantum kapıları oyunu.
<br>İndirmeden oynamak için tıklayın: https://editor.p5js.org/atasoglu/full/oOBTfSKt- 
